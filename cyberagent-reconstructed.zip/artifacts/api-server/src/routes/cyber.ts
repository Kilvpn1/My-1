import { Router, type IRouter } from "express";
import OpenAI from "openai";
 
const router: IRouter = Router();
 
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY ?? "dummy",
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});
 
router.post("/cyber/chat", async (req, res) => {
  try {
    const { messages } = req.body as {
      messages: Array<{ role: "system" | "user" | "assistant"; content: string }>;
    };
 
    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache, no-transform");
    res.setHeader("X-Accel-Buffering", "no");
    res.setHeader("Connection", "keep-alive");
    res.flushHeaders();
 
    const stream = await openai.chat.completions.create({
      model: "gpt-5.2",
      messages,
      stream: true,
      max_completion_tokens: 8192,
    });
 
    for await (const chunk of stream) {
      const content = chunk.choices[0]?.delta?.content;
      if (content) {
        res.write(`data: ${JSON.stringify({ content })}\n\n`);
      }
    }
 
    res.write("data: [DONE]\n\n");
    res.end();
  } catch (err) {
    if (!res.headersSent) {
      res.status(500).json({ error: "Internal server error" });
    } else {
      res.write(`data: ${JSON.stringify({ content: "\n\n[Erro ao conectar com o servidor IA]" })}\n\n`);
      res.write("data: [DONE]\n\n");
      res.end();
    }
  }
});
 
export default router;
