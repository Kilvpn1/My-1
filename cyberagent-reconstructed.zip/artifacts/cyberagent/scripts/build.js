const { spawnSync } = require("node:child_process");

const result = spawnSync("npx", ["expo", "export", "--platform", "web"], {
  stdio: "inherit",
  shell: true,
  env: process.env,
});

process.exit(result.status ?? 1);
