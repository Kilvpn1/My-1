import AsyncStorage from "@react-native-async-storage/async-storage";
import { fetch } from "expo/fetch";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
import { setBaseUrl } from "@workspace/api-client-react";
 
export interface Message {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  timestamp: number;
}
 
interface ChatContextType {
  messages: Message[];
  isStreaming: boolean;
  showTyping: boolean;
  sendMessage: (text: string) => Promise<void>;
  clearChat: () => void;
}
 
const ChatContext = createContext<ChatContextType | null>(null);
 
const SYSTEM_PROMPT = `Você é CyberAgent, um assistente especialista em segurança cibernética para Android. 
Você tem acesso às funções de monitoramento do sistema, firewall e proteção contra ameaças.
Responda sempre em português brasileiro de forma clara e objetiva.
Quando o usuário pedir para executar ações (encerrar processo, bloquear app, verificar link), confirme a ação e descreva o que foi feito.
Seja proativo em alertar sobre riscos de segurança. Use termos técnicos quando apropriado mas explique-os.
Mantenha as respostas concisas para mobile. Use listas quando listar múltiplos itens.`;
 
export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "welcome",
      role: "assistant",
      content: "Olá! Sou o CyberAgent, seu assistente de segurança cibernética para Android 16. Posso monitorar processos, gerenciar firewall, verificar links suspeitos e proteger seu dispositivo. Como posso ajudar?",
      timestamp: Date.now(),
    }
  ]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [showTyping, setShowTyping] = useState(false);
 
  useEffect(() => {
    if (process.env.EXPO_PUBLIC_DOMAIN) {
      setBaseUrl(`https://${process.env.EXPO_PUBLIC_DOMAIN}`);
    }
  }, []);
 
  useEffect(() => {
    const load = async () => {
      try {
        const stored = await AsyncStorage.getItem("cyberagent_chat");
        if (stored) {
          const parsed = JSON.parse(stored);
          if (parsed.length > 0) setMessages(parsed);
        }
      } catch {}
    };
    load();
  }, []);
 
  useEffect(() => {
    AsyncStorage.setItem("cyberagent_chat", JSON.stringify(messages.slice(-50)));
  }, [messages]);
 
  const sendMessage = useCallback(async (text: string) => {
    const userMsg: Message = {
      id: Date.now().toString() + "u",
      role: "user",
      content: text,
      timestamp: Date.now(),
    };
 
    const currentMessages = [...messages];
    setMessages(prev => [...prev, userMsg]);
    setIsStreaming(true);
    setShowTyping(true);
 
    let fullContent = "";
    let assistantAdded = false;
 
    try {
      const baseUrl = process.env.EXPO_PUBLIC_DOMAIN
        ? `https://${process.env.EXPO_PUBLIC_DOMAIN}`
        : "";
 
      const chatHistory = [
        { role: "system", content: SYSTEM_PROMPT },
        ...currentMessages
          .filter(m => m.role !== "system")
          .slice(-20)
          .map(m => ({ role: m.role, content: m.content })),
        { role: "user", content: text },
      ];
 
      const response = await fetch(`${baseUrl}/api/cyber/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "text/event-stream",
        },
        body: JSON.stringify({ messages: chatHistory }),
      });
 
      if (!response.ok) throw new Error("Falha na conexão com o servidor");
 
      const reader = response.body?.getReader();
      if (!reader) throw new Error("Sem resposta do servidor");
 
      const decoder = new TextDecoder();
      let buffer = "";
 
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
 
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
 
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const data = line.slice(6);
          if (data === "[DONE]") continue;
          try {
            const parsed = JSON.parse(data);
            if (parsed.content) {
              fullContent += parsed.content;
              if (!assistantAdded) {
                setShowTyping(false);
                setMessages(prev => [...prev, {
                  id: Date.now().toString() + "a",
                  role: "assistant",
                  content: parsed.content,
                  timestamp: Date.now(),
                }]);
                assistantAdded = true;
              } else {
                setMessages(prev => {
                  const updated = [...prev];
                  updated[updated.length - 1] = {
                    ...updated[updated.length - 1],
                    content: fullContent,
                  };
                  return updated;
                });
              }
            }
          } catch {}
        }
      }
    } catch (error) {
      setShowTyping(false);
      if (!assistantAdded) {
        setMessages(prev => [...prev, {
          id: Date.now().toString() + "err",
          role: "assistant",
          content: "Desculpe, ocorreu um erro ao processar sua mensagem. Verifique sua conexão e tente novamente.",
          timestamp: Date.now(),
        }]);
      }
    } finally {
      setIsStreaming(false);
      setShowTyping(false);
    }
  }, [messages]);
 
  const clearChat = useCallback(() => {
    setMessages([{
      id: "welcome-reset",
      role: "assistant",
      content: "Chat reiniciado. Como posso ajudar com a segurança do seu dispositivo?",
      timestamp: Date.now(),
    }]);
  }, []);
 
  return (
    <ChatContext.Provider value={{ messages, isStreaming, showTyping, sendMessage, clearChat }}>
      {children}
    </ChatContext.Provider>
  );
}
 
export function useChat() {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error("useChat must be used inside ChatProvider");
  return ctx;
}
