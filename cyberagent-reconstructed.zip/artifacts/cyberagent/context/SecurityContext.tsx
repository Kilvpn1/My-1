import AsyncStorage from "@react-native-async-storage/async-storage";
import React, { createContext, useCallback, useContext, useEffect, useState } from "react";
 
export type ThreatLevel = "safe" | "warning" | "danger";
 
export interface Process {
  id: string;
  name: string;
  packageName: string;
  cpu: number;
  memory: number;
  status: "running" | "sleeping" | "stopped";
  trusted: boolean;
  network: boolean;
  flags: string[];
}
 
export interface FirewallRule {
  id: string;
  packageName: string;
  appName: string;
  allowed: boolean;
  createdAt: number;
}
 
export interface Alert {
  id: string;
  type: "process" | "firewall" | "link" | "system";
  severity: "info" | "warning" | "danger";
  title: string;
  description: string;
  timestamp: number;
  resolved: boolean;
  requiresAction: boolean;
  pendingAction?: {
    label: string;
    onApprove: () => void;
    onDeny: () => void;
  };
}
 
export interface ScanResult {
  url: string;
  safe: boolean;
  threats: string[];
  timestamp: number;
}
 
interface SecurityContextType {
  threatLevel: ThreatLevel;
  processes: Process[];
  firewallRules: FirewallRule[];
  alerts: Alert[];
  scanResults: ScanResult[];
  isMonitoring: boolean;
  shizukuConnected: boolean;
  pendingAlerts: Alert[];
  startMonitoring: () => void;
  stopMonitoring: () => void;
  toggleFirewall: (packageName: string) => void;
  scanUrl: (url: string) => Promise<ScanResult>;
  resolveAlert: (id: string) => void;
  addAlert: (alert: Omit<Alert, "id" | "timestamp" | "resolved">) => void;
  connectShizuku: () => Promise<boolean>;
  killProcess: (processId: string) => Promise<boolean>;
  approveAction: (alertId: string) => void;
  denyAction: (alertId: string) => void;
}
 
const SecurityContext = createContext<SecurityContextType | null>(null);
 
const MOCK_PROCESSES: Process[] = [
  { id: "1", name: "System Server", packageName: "android", cpu: 2.1, memory: 128, status: "running", trusted: true, network: true, flags: [] },
  { id: "2", name: "Chrome", packageName: "com.android.chrome", cpu: 8.4, memory: 256, status: "running", trusted: true, network: true, flags: [] },
  { id: "3", name: "WhatsApp", packageName: "com.whatsapp", cpu: 1.2, memory: 196, status: "running", trusted: true, network: true, flags: [] },
  { id: "4", name: "com.suspicious.app", packageName: "com.suspicious.app", cpu: 15.7, memory: 512, status: "running", trusted: false, network: true, flags: ["HIGH_CPU", "BACKGROUND_NETWORK"] },
  { id: "5", name: "Camera", packageName: "com.android.camera2", cpu: 0.3, memory: 64, status: "sleeping", trusted: true, network: false, flags: [] },
  { id: "6", name: "Settings", packageName: "com.android.settings", cpu: 0.1, memory: 48, status: "sleeping", trusted: true, network: false, flags: [] },
  { id: "7", name: "com.adware.tracker", packageName: "com.adware.tracker", cpu: 23.1, memory: 384, status: "running", trusted: false, network: true, flags: ["HIGH_CPU", "BACKGROUND_NETWORK", "SUSPICIOUS"] },
];
 
const MOCK_FIREWALL_RULES: FirewallRule[] = [
  { id: "1", packageName: "com.android.chrome", appName: "Chrome", allowed: true, createdAt: Date.now() - 86400000 },
  { id: "2", packageName: "com.whatsapp", appName: "WhatsApp", allowed: true, createdAt: Date.now() - 172800000 },
  { id: "3", packageName: "com.suspicious.app", appName: "com.suspicious.app", allowed: false, createdAt: Date.now() - 3600000 },
  { id: "4", packageName: "com.adware.tracker", appName: "com.adware.tracker", allowed: false, createdAt: Date.now() - 1800000 },
];
 
export function SecurityProvider({ children }: { children: React.ReactNode }) {
  const [processes, setProcesses] = useState<Process[]>(MOCK_PROCESSES);
  const [firewallRules, setFirewallRules] = useState<FirewallRule[]>(MOCK_FIREWALL_RULES);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [scanResults, setScanResults] = useState<ScanResult[]>([]);
  const [isMonitoring, setIsMonitoring] = useState(false);
  const [shizukuConnected, setShizukuConnected] = useState(false);
  const [pendingAlerts, setPendingAlerts] = useState<Alert[]>([]);
 
  const threatLevel: ThreatLevel = (() => {
    const unresolved = alerts.filter(a => !a.resolved);
    if (unresolved.some(a => a.severity === "danger")) return "danger";
    if (unresolved.some(a => a.severity === "warning")) return "warning";
    return "safe";
  })();
 
  const addAlert = useCallback((alert: Omit<Alert, "id" | "timestamp" | "resolved">) => {
    const newAlert: Alert = {
      ...alert,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
      timestamp: Date.now(),
      resolved: false,
    };
    setAlerts(prev => [newAlert, ...prev]);
    if (alert.requiresAction) {
      setPendingAlerts(prev => [newAlert, ...prev]);
    }
  }, []);
 
  const startMonitoring = useCallback(() => {
    setIsMonitoring(true);
    addAlert({
      type: "system",
      severity: "info",
      title: "Monitoramento Iniciado",
      description: "CyberAgent está monitorando seu sistema Android 16 em tempo real.",
      requiresAction: false,
    });
 
    setTimeout(() => {
      addAlert({
        type: "process",
        severity: "danger",
        title: "Processo Suspeito Detectado",
        description: "com.adware.tracker está usando 23% de CPU em segundo plano e enviando dados pela rede.",
        requiresAction: true,
      });
    }, 3000);
 
    setTimeout(() => {
      addAlert({
        type: "link",
        severity: "warning",
        title: "Link Malicioso Bloqueado",
        description: "Tentativa de acesso a domínio de phishing: secure-bank-verify.xyz",
        requiresAction: false,
      });
    }, 8000);
  }, [addAlert]);
 
  const stopMonitoring = useCallback(() => {
    setIsMonitoring(false);
    addAlert({
      type: "system",
      severity: "info",
      title: "Monitoramento Pausado",
      description: "O monitoramento em tempo real foi pausado.",
      requiresAction: false,
    });
  }, [addAlert]);
 
  const toggleFirewall = useCallback((packageName: string) => {
    setFirewallRules(prev => {
      const existing = prev.find(r => r.packageName === packageName);
      if (existing) {
        return prev.map(r => r.packageName === packageName ? { ...r, allowed: !r.allowed } : r);
      }
      const proc = processes.find(p => p.packageName === packageName);
      return [...prev, {
        id: Date.now().toString(),
        packageName,
        appName: proc?.name ?? packageName,
        allowed: false,
        createdAt: Date.now(),
      }];
    });
  }, [processes]);
 
  const scanUrl = useCallback(async (url: string): Promise<ScanResult> => {
    await new Promise(r => setTimeout(r, 1500));
 
    const phishingPatterns = ["secure-bank", "verify-account", "login-confirm", "paypal-secure", "amazon-verify", "free-prize"];
    const malwarePatterns = ["download-free", "crack-", "keygen", ".tk/", ".ml/", "bit.ly/abuse"];
    const redirectPatterns = ["redirect=", "?goto=", "?url=", "forward?"];
 
    const threats: string[] = [];
    const lower = url.toLowerCase();
 
    if (phishingPatterns.some(p => lower.includes(p))) threats.push("Phishing");
    if (malwarePatterns.some(p => lower.includes(p))) threats.push("Malware");
    if (redirectPatterns.some(p => lower.includes(p))) threats.push("Redirecionamento Suspeito");
    if (!url.startsWith("https://")) threats.push("Conexão não segura (HTTP)");
 
    const result: ScanResult = {
      url,
      safe: threats.length === 0,
      threats,
      timestamp: Date.now(),
    };
 
    setScanResults(prev => [result, ...prev.slice(0, 9)]);
 
    if (!result.safe) {
      addAlert({
        type: "link",
        severity: threats.includes("Malware") ? "danger" : "warning",
        title: "Link Perigoso Detectado",
        description: `${url} — Ameaças: ${threats.join(", ")}`,
        requiresAction: false,
      });
    }
 
    return result;
  }, [addAlert]);
 
  const resolveAlert = useCallback((id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, resolved: true } : a));
    setPendingAlerts(prev => prev.filter(a => a.id !== id));
  }, []);
 
  const connectShizuku = useCallback(async (): Promise<boolean> => {
    await new Promise(r => setTimeout(r, 2000));
    setShizukuConnected(true);
    addAlert({
      type: "system",
      severity: "info",
      title: "Shizuku Conectado",
      description: "Permissões de root concedidas via Shizuku. Acesso a operações privilegiadas ativado.",
      requiresAction: false,
    });
    return true;
  }, [addAlert]);
 
  const killProcess = useCallback(async (processId: string): Promise<boolean> => {
    if (!shizukuConnected) return false;
    await new Promise(r => setTimeout(r, 800));
    setProcesses(prev => prev.filter(p => p.id !== processId));
    addAlert({
      type: "process",
      severity: "info",
      title: "Processo Encerrado",
      description: "Processo foi encerrado com sucesso via Shizuku.",
      requiresAction: false,
    });
    return true;
  }, [shizukuConnected, addAlert]);
 
  const approveAction = useCallback((alertId: string) => {
    resolveAlert(alertId);
  }, [resolveAlert]);
 
  const denyAction = useCallback((alertId: string) => {
    resolveAlert(alertId);
  }, [resolveAlert]);
 
  useEffect(() => {
    const load = async () => {
      try {
        const stored = await AsyncStorage.getItem("cyberagent_alerts");
        if (stored) setAlerts(JSON.parse(stored));
      } catch {}
    };
    load();
  }, []);
 
  useEffect(() => {
    AsyncStorage.setItem("cyberagent_alerts", JSON.stringify(alerts.slice(0, 50)));
  }, [alerts]);
 
  return (
    <SecurityContext.Provider value={{
      threatLevel,
      processes,
      firewallRules,
      alerts,
      scanResults,
      isMonitoring,
      shizukuConnected,
      pendingAlerts,
      startMonitoring,
      stopMonitoring,
      toggleFirewall,
      scanUrl,
      resolveAlert,
      addAlert,
      connectShizuku,
      killProcess,
      approveAction,
      denyAction,
    }}>
      {children}
    </SecurityContext.Provider>
  );
}
 
export function useSecurity() {
  const ctx = useContext(SecurityContext);
  if (!ctx) throw new Error("useSecurity must be used inside SecurityProvider");
  return ctx;
}
