const primary = "#00D4FF";
const primaryDark = "#0099CC";
const accent = "#00FF88";
const danger = "#FF4444";
const warning = "#FFB800";
const bg = "#060A0F";
const surface = "#0D1520";
const surfaceLight = "#152030";
const border = "#1A2E45";
const textPrimary = "#E8F4FF";
const textSecondary = "#6B8BA4";
 
export default {
  primary,
  primaryDark,
  accent,
  danger,
  warning,
  bg,
  surface,
  surfaceLight,
  border,
  textPrimary,
  textSecondary,
  tabIconDefault: textSecondary,
  tabIconSelected: primary,
  tint: primary,
 
  dark: {
    background: bg,
    surface,
    surfaceLight,
    border,
    text: textPrimary,
    textSecondary,
    primary,
    accent,
    danger,
    warning,
  },
};
