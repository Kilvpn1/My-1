/// <reference types="expo/types" />

// Arquivo reconstruído a partir da documentação.
