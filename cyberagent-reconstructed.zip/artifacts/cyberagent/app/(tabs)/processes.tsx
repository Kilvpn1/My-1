import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  Alert,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import Animated, { FadeIn, FadeOut } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Colors from "@/constants/colors";
import { useSecurity, Process } from "@/context/SecurityContext";
 
function CpuBar({ value }: { value: number }) {
  const color = value > 20 ? Colors.danger : value > 10 ? Colors.warning : Colors.accent;
  return (
    <View style={styles.cpuBar}>
      <View style={[styles.cpuFill, { width: `${Math.min(value, 100)}%` as any, backgroundColor: color }]} />
    </View>
  );
}
 
function ProcessCard({ process, onKill }: { process: Process; onKill: (id: string) => void }) {
  const { shizukuConnected } = useSecurity();
  const isSuspicious = !process.trusted;
  const hasDanger = process.flags.includes("SUSPICIOUS");
  const borderColor = hasDanger ? Colors.danger : isSuspicious ? Colors.warning : Colors.border;
 
  const handleKill = () => {
    if (!shizukuConnected) {
      Alert.alert("Shizuku necessário", "Conecte o Shizuku para encerrar processos com privilégios.");
      return;
    }
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    Alert.alert(
      "Encerrar Processo",
      `Deseja encerrar "${process.name}"?`,
      [
        { text: "Cancelar", style: "cancel" },
        { text: "Encerrar", style: "destructive", onPress: () => onKill(process.id) },
      ]
    );
  };
 
  return (
    <Animated.View entering={FadeIn} exiting={FadeOut} style={[styles.card, { borderLeftColor: borderColor, borderLeftWidth: 3 }]}>
      <View style={styles.cardTop}>
        <View style={[styles.procIcon, { backgroundColor: isSuspicious ? Colors.danger + "22" : Colors.surface }]}>
          <MaterialCommunityIcons
            name={isSuspicious ? "virus" : "cpu-64-bit"}
            size={20}
            color={isSuspicious ? Colors.danger : Colors.primary}
          />
        </View>
        <View style={styles.procInfo}>
          <Text style={styles.procName} numberOfLines={1}>{process.name}</Text>
          <Text style={styles.procPkg} numberOfLines={1}>{process.packageName}</Text>
        </View>
        <View style={[styles.statusBadge, { backgroundColor: process.status === "running" ? Colors.accent + "22" : Colors.textSecondary + "22" }]}>
          <Text style={[styles.statusText, { color: process.status === "running" ? Colors.accent : Colors.textSecondary }]}>
            {process.status === "running" ? "Ativo" : "Dormindo"}
          </Text>
        </View>
      </View>
 
      <View style={styles.statsRow}>
        <View style={styles.stat}>
          <Text style={styles.statLabel}>CPU</Text>
          <Text style={[styles.statVal, { color: process.cpu > 15 ? Colors.danger : Colors.textPrimary }]}>
            {process.cpu.toFixed(1)}%
          </Text>
          <CpuBar value={process.cpu} />
        </View>
        <View style={[styles.stat, styles.statMid]}>
          <Text style={styles.statLabel}>Memória</Text>
          <Text style={styles.statVal}>{process.memory}MB</Text>
        </View>
        <View style={styles.stat}>
          <Text style={styles.statLabel}>Rede</Text>
          <MaterialCommunityIcons
            name={process.network ? "wifi" : "wifi-off"}
            size={16}
            color={process.network ? Colors.warning : Colors.textSecondary}
          />
        </View>
      </View>
 
      {process.flags.length > 0 && (
        <View style={styles.flagsRow}>
          {process.flags.map(flag => (
            <View key={flag} style={styles.flag}>
              <Text style={styles.flagText}>{flag.replace(/_/g, " ")}</Text>
            </View>
          ))}
        </View>
      )}
 
      {isSuspicious && (
        <View style={styles.cardActions}>
          <Pressable
            style={[styles.killBtn, !shizukuConnected && styles.killBtnDisabled]}
            onPress={handleKill}
          >
            <Feather name="stop-circle" size={14} color={shizukuConnected ? Colors.danger : Colors.textSecondary} />
            <Text style={[styles.killBtnText, { color: shizukuConnected ? Colors.danger : Colors.textSecondary }]}>
              {shizukuConnected ? "Encerrar Processo" : "Requer Shizuku"}
            </Text>
          </Pressable>
        </View>
      )}
    </Animated.View>
  );
}
 
type Filter = "all" | "suspicious" | "network";
 
export default function ProcessesScreen() {
  const insets = useSafeAreaInsets();
  const { processes, killProcess } = useSecurity();
  const [filter, setFilter] = useState<Filter>("all");
 
  const filtered = processes.filter(p => {
    if (filter === "suspicious") return !p.trusted;
    if (filter === "network") return p.network;
    return true;
  });
 
  const topPad = Platform.OS === "web" ? 67 : insets.top;
 
  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Monitor de Processos</Text>
        <Text style={styles.sub}>{processes.length} processos ativos</Text>
      </View>
 
      <View style={styles.filterRow}>
        {([["all", "Todos"], ["suspicious", "Suspeitos"], ["network", "Com Rede"]] as [Filter, string][]).map(([key, label]) => (
          <Pressable
            key={key}
            style={[styles.filterBtn, filter === key && styles.filterBtnActive]}
            onPress={() => setFilter(key)}
          >
            <Text style={[styles.filterText, filter === key && styles.filterTextActive]}>
              {label}
            </Text>
          </Pressable>
        ))}
      </View>
 
      <FlatList
        data={filtered}
        renderItem={({ item }) => (
          <ProcessCard
            process={item}
            onKill={async (id) => { await killProcess(id); }}
          />
        )}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 100 }]}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="cpu-64-bit" size={40} color={Colors.textSecondary} />
            <Text style={styles.emptyText}>Nenhum processo encontrado</Text>
          </View>
        }
      />
    </View>
  );
}
 
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 12 },
  title: { fontFamily: "Inter_700Bold", fontSize: 22, color: Colors.textPrimary },
  sub: { fontFamily: "Inter_400Regular", fontSize: 13, color: Colors.textSecondary, marginTop: 2 },
  filterRow: { flexDirection: "row", gap: 8, paddingHorizontal: 20, marginBottom: 16 },
  filterBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border },
  filterBtnActive: { backgroundColor: Colors.primary + "22", borderColor: Colors.primary },
  filterText: { fontFamily: "Inter_500Medium", fontSize: 13, color: Colors.textSecondary },
  filterTextActive: { color: Colors.primary },
  list: { paddingHorizontal: 16 },
  card: { backgroundColor: Colors.surface, borderRadius: 14, marginBottom: 10, padding: 14, borderWidth: 1, borderColor: Colors.border },
  cardTop: { flexDirection: "row", alignItems: "center", gap: 10, marginBottom: 12 },
  procIcon: { width: 40, height: 40, borderRadius: 10, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: Colors.border },
  procInfo: { flex: 1 },
  procName: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: Colors.textPrimary },
  procPkg: { fontFamily: "Inter_400Regular", fontSize: 11, color: Colors.textSecondary, marginTop: 2 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  statusText: { fontFamily: "Inter_500Medium", fontSize: 11 },
  statsRow: { flexDirection: "row", borderTopWidth: 1, borderTopColor: Colors.border, paddingTop: 10 },
  stat: { flex: 1, alignItems: "center", gap: 4 },
  statMid: { borderLeftWidth: 1, borderRightWidth: 1, borderColor: Colors.border },
  statLabel: { fontFamily: "Inter_400Regular", fontSize: 11, color: Colors.textSecondary },
  statVal: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: Colors.textPrimary },
  cpuBar: { width: 60, height: 4, backgroundColor: Colors.border, borderRadius: 2, overflow: "hidden" },
  cpuFill: { height: "100%", borderRadius: 2 },
  flagsRow: { flexDirection: "row", flexWrap: "wrap", gap: 6, marginTop: 8 },
  flag: { backgroundColor: Colors.warning + "22", borderWidth: 1, borderColor: Colors.warning + "44", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 },
  flagText: { fontFamily: "Inter_500Medium", fontSize: 10, color: Colors.warning },
  cardActions: { borderTopWidth: 1, borderTopColor: Colors.border, marginTop: 12, paddingTop: 10 },
  killBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: Colors.danger + "18", borderWidth: 1, borderColor: Colors.danger + "44", borderRadius: 8, paddingVertical: 8 },
  killBtnDisabled: { backgroundColor: Colors.surface, borderColor: Colors.border },
  killBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
  empty: { alignItems: "center", gap: 10, paddingTop: 60 },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 14, color: Colors.textSecondary },
});
