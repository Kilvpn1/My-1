import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  ActivityIndicator,
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import Animated, { FadeIn } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Colors from "@/constants/colors";
import { useSecurity, ScanResult } from "@/context/SecurityContext";
 
function ScanResultCard({ result }: { result: ScanResult }) {
  const color = result.safe ? Colors.accent : Colors.danger;
  const icon = result.safe ? "shield-check" : "shield-alert";
 
  return (
    <Animated.View entering={FadeIn} style={[styles.resultCard, { borderLeftColor: color }]}>
      <View style={styles.resultTop}>
        <View style={[styles.resultIcon, { backgroundColor: color + "22" }]}>
          <MaterialCommunityIcons name={icon as any} size={20} color={color} />
        </View>
        <View style={styles.resultInfo}>
          <Text style={[styles.resultStatus, { color }]}>
            {result.safe ? "Link Seguro" : "Ameaça Detectada"}
          </Text>
          <Text style={styles.resultUrl} numberOfLines={2}>{result.url}</Text>
          <Text style={styles.resultTime}>
            {new Date(result.timestamp).toLocaleString("pt-BR")}
          </Text>
        </View>
      </View>
      {result.threats.length > 0 && (
        <View style={styles.threatsWrap}>
          {result.threats.map(t => (
            <View key={t} style={styles.threatChip}>
              <Feather name="alert-triangle" size={11} color={Colors.danger} />
              <Text style={styles.threatText}>{t}</Text>
            </View>
          ))}
        </View>
      )}
    </Animated.View>
  );
}
 
const EXAMPLE_URLS = [
  "https://google.com",
  "http://secure-bank-verify.xyz/login",
  "https://amazon.com.br",
  "http://download-free-crack.tk/file.apk",
  "https://github.com",
];
 
export default function ScannerScreen() {
  const insets = useSafeAreaInsets();
  const { scanResults, scanUrl } = useSecurity();
  const [url, setUrl] = useState("");
  const [isScanning, setIsScanning] = useState(false);
  const [lastResult, setLastResult] = useState<ScanResult | null>(null);
 
  const handleScan = async () => {
    if (!url.trim() || isScanning) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setIsScanning(true);
    setLastResult(null);
    try {
      const result = await scanUrl(url.trim());
      setLastResult(result);
      Haptics.notificationAsync(result.safe ? Haptics.NotificationFeedbackType.Success : Haptics.NotificationFeedbackType.Error);
    } finally {
      setIsScanning(false);
    }
  };
 
  const topPad = Platform.OS === "web" ? 67 : insets.top;
 
  return (
    <KeyboardAvoidingView
      style={[styles.container, { paddingTop: topPad }]}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      <View style={styles.header}>
        <Text style={styles.title}>Scanner de Links</Text>
        <Text style={styles.sub}>Detecta phishing, malware e redirecionamentos</Text>
      </View>
 
      <View style={styles.scanArea}>
        <View style={styles.inputWrap}>
          <MaterialCommunityIcons name="link-variant" size={18} color={Colors.textSecondary} style={styles.inputIcon} />
          <TextInput
            style={styles.input}
            value={url}
            onChangeText={setUrl}
            placeholder="Cole ou digite o URL para verificar"
            placeholderTextColor={Colors.textSecondary}
            autoCapitalize="none"
            autoCorrect={false}
            keyboardType="url"
            returnKeyType="done"
            onSubmitEditing={handleScan}
          />
          {url.length > 0 && (
            <Pressable onPress={() => setUrl("")}>
              <Feather name="x-circle" size={18} color={Colors.textSecondary} />
            </Pressable>
          )}
        </View>
 
        <Pressable
          style={[styles.scanBtn, (!url.trim() || isScanning) && styles.scanBtnDisabled]}
          onPress={handleScan}
          disabled={!url.trim() || isScanning}
        >
          {isScanning ? (
            <ActivityIndicator size="small" color="#000" />
          ) : (
            <MaterialCommunityIcons name="shield-search" size={20} color={url.trim() ? "#000" : Colors.textSecondary} />
          )}
          <Text style={[styles.scanBtnText, !url.trim() && { color: Colors.textSecondary }]}>
            {isScanning ? "Analisando..." : "Analisar Link"}
          </Text>
        </Pressable>
 
        {lastResult && (
          <View style={[styles.resultInline, { borderColor: lastResult.safe ? Colors.accent : Colors.danger, backgroundColor: (lastResult.safe ? Colors.accent : Colors.danger) + "11" }]}>
            <MaterialCommunityIcons
              name={lastResult.safe ? "shield-check" : "shield-alert"}
              size={28}
              color={lastResult.safe ? Colors.accent : Colors.danger}
            />
            <View style={{ flex: 1 }}>
              <Text style={[styles.resultInlineTitle, { color: lastResult.safe ? Colors.accent : Colors.danger }]}>
                {lastResult.safe ? "Link seguro" : "Ameaça detectada!"}
              </Text>
              {lastResult.threats.length > 0 && (
                <Text style={styles.resultInlineSub}>{lastResult.threats.join(", ")}</Text>
              )}
            </View>
          </View>
        )}
      </View>
 
      <View style={styles.exampleSection}>
        <Text style={styles.exampleLabel}>Exemplos para testar</Text>
        <View style={styles.exampleRow}>
          {EXAMPLE_URLS.slice(0, 3).map(e => (
            <Pressable key={e} style={styles.exampleChip} onPress={() => setUrl(e)}>
              <Text style={styles.exampleText} numberOfLines={1}>{e.replace("https://", "").replace("http://", "")}</Text>
            </Pressable>
          ))}
        </View>
      </View>
 
      {scanResults.length > 0 && (
        <>
          <View style={styles.historyHeader}>
            <Text style={styles.historyTitle}>Histórico de Scans</Text>
          </View>
          <FlatList
            data={scanResults}
            renderItem={({ item }) => <ScanResultCard result={item} />}
            keyExtractor={(item, i) => item.timestamp.toString() + i}
            contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 100 }]}
            showsVerticalScrollIndicator={false}
          />
        </>
      )}
 
      {scanResults.length === 0 && !lastResult && (
        <View style={styles.empty}>
          <MaterialCommunityIcons name="magnify-scan" size={52} color={Colors.textSecondary + "55"} />
          <Text style={styles.emptyTitle}>Nenhum scan realizado</Text>
          <Text style={styles.emptyText}>Cole um URL acima para verificar se é seguro</Text>
        </View>
      )}
    </KeyboardAvoidingView>
  );
}
 
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 16 },
  title: { fontFamily: "Inter_700Bold", fontSize: 22, color: Colors.textPrimary },
  sub: { fontFamily: "Inter_400Regular", fontSize: 13, color: Colors.textSecondary, marginTop: 2 },
  scanArea: { paddingHorizontal: 16, marginBottom: 16, gap: 12 },
  inputWrap: { flexDirection: "row", alignItems: "center", backgroundColor: Colors.surface, borderRadius: 14, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 14, paddingVertical: 12, gap: 10 },
  inputIcon: { marginRight: 2 },
  input: { flex: 1, fontFamily: "Inter_400Regular", fontSize: 13, color: Colors.textPrimary },
  scanBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: Colors.primary, borderRadius: 14, paddingVertical: 14 },
  scanBtnDisabled: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border },
  scanBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 15, color: "#000" },
  resultInline: { flexDirection: "row", alignItems: "center", gap: 12, borderRadius: 14, borderWidth: 1.5, padding: 14 },
  resultInlineTitle: { fontFamily: "Inter_700Bold", fontSize: 15 },
  resultInlineSub: { fontFamily: "Inter_400Regular", fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
  exampleSection: { paddingHorizontal: 16, marginBottom: 20 },
  exampleLabel: { fontFamily: "Inter_500Medium", fontSize: 12, color: Colors.textSecondary, marginBottom: 8 },
  exampleRow: { flexDirection: "row", gap: 8 },
  exampleChip: { flex: 1, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: 10, paddingHorizontal: 10, paddingVertical: 7, alignItems: "center" },
  exampleText: { fontFamily: "Inter_400Regular", fontSize: 11, color: Colors.primary },
  historyHeader: { paddingHorizontal: 16, marginBottom: 10 },
  historyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 15, color: Colors.textPrimary },
  list: { paddingHorizontal: 16 },
  resultCard: { backgroundColor: Colors.surface, borderRadius: 14, marginBottom: 10, borderLeftWidth: 3, borderWidth: 1, borderColor: Colors.border, overflow: "hidden" },
  resultTop: { flexDirection: "row", gap: 12, padding: 14 },
  resultIcon: { width: 40, height: 40, borderRadius: 10, alignItems: "center", justifyContent: "center" },
  resultInfo: { flex: 1 },
  resultStatus: { fontFamily: "Inter_700Bold", fontSize: 13 },
  resultUrl: { fontFamily: "Inter_400Regular", fontSize: 12, color: Colors.textSecondary, marginTop: 2, lineHeight: 16 },
  resultTime: { fontFamily: "Inter_400Regular", fontSize: 10, color: Colors.textSecondary + "88", marginTop: 4 },
  threatsWrap: { flexDirection: "row", flexWrap: "wrap", gap: 6, paddingHorizontal: 14, paddingBottom: 12 },
  threatChip: { flexDirection: "row", alignItems: "center", gap: 4, backgroundColor: Colors.danger + "18", borderWidth: 1, borderColor: Colors.danger + "44", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 4 },
  threatText: { fontFamily: "Inter_500Medium", fontSize: 11, color: Colors.danger },
  empty: { flex: 1, alignItems: "center", justifyContent: "center", gap: 10, paddingBottom: 80 },
  emptyTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16, color: Colors.textSecondary },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 13, color: Colors.textSecondary + "88", textAlign: "center", paddingHorizontal: 40 },
});
