import { Feather, MaterialCommunityIcons, Ionicons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useEffect, useRef, useState } from "react";
import {
  Animated,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Colors from "@/constants/colors";
import { useSecurity, Alert } from "@/context/SecurityContext";
 
function ThreatRing({ level }: { level: "safe" | "warning" | "danger" }) {
  const pulse = useRef(new Animated.Value(1)).current;
  const color = level === "safe" ? Colors.accent : level === "warning" ? Colors.warning : Colors.danger;
 
  useEffect(() => {
    if (level !== "safe") {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulse, { toValue: 1.12, duration: 900, useNativeDriver: true }),
          Animated.timing(pulse, { toValue: 1, duration: 900, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulse.setValue(1);
    }
  }, [level]);
 
  const label = level === "safe" ? "SEGURO" : level === "warning" ? "ATENÇÃO" : "PERIGO";
 
  return (
    <View style={styles.threatRingContainer}>
      <Animated.View style={[styles.outerRing, { borderColor: color + "33", transform: [{ scale: pulse }] }]} />
      <Animated.View style={[styles.middleRing, { borderColor: color + "66" }]} />
      <View style={[styles.innerCircle, { backgroundColor: color + "18", borderColor: color }]}>
        <MaterialCommunityIcons
          name={level === "safe" ? "shield-check" : level === "warning" ? "shield-alert" : "shield-off"}
          size={44}
          color={color}
        />
        <Text style={[styles.threatLabel, { color }]}>{label}</Text>
      </View>
    </View>
  );
}
 
function StatCard({ icon, label, value, color }: { icon: string; label: string; value: string; color: string }) {
  return (
    <View style={styles.statCard}>
      <MaterialCommunityIcons name={icon as any} size={20} color={color} />
      <Text style={styles.statValue}>{value}</Text>
      <Text style={styles.statLabel}>{label}</Text>
    </View>
  );
}
 
function AlertItem({ alert, onResolve, onApprove, onDeny }: {
  alert: Alert;
  onResolve: (id: string) => void;
  onApprove: (id: string) => void;
  onDeny: (id: string) => void;
}) {
  const color = alert.severity === "danger" ? Colors.danger : alert.severity === "warning" ? Colors.warning : Colors.primary;
  const iconName = alert.type === "process" ? "cpu-64-bit" : alert.type === "firewall" ? "firewall" : alert.type === "link" ? "link-variant" : "information";
 
  return (
    <View style={[styles.alertItem, { borderLeftColor: color }]}>
      <View style={styles.alertHeader}>
        <View style={[styles.alertIconWrap, { backgroundColor: color + "22" }]}>
          <MaterialCommunityIcons name={iconName as any} size={16} color={color} />
        </View>
        <View style={styles.alertContent}>
          <Text style={styles.alertTitle}>{alert.title}</Text>
          <Text style={styles.alertDesc} numberOfLines={2}>{alert.description}</Text>
          <Text style={styles.alertTime}>{new Date(alert.timestamp).toLocaleTimeString("pt-BR")}</Text>
        </View>
        {!alert.requiresAction && (
          <Pressable onPress={() => onResolve(alert.id)} style={styles.dismissBtn}>
            <Feather name="x" size={14} color={Colors.textSecondary} />
          </Pressable>
        )}
      </View>
      {alert.requiresAction && (
        <View style={styles.actionRow}>
          <Text style={styles.actionLabel}>Autorizar esta ação?</Text>
          <View style={styles.actionBtns}>
            <Pressable
              style={[styles.actionBtn, styles.denyBtn]}
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); onDeny(alert.id); }}
            >
              <Feather name="x" size={14} color={Colors.danger} />
              <Text style={[styles.actionBtnText, { color: Colors.danger }]}>Negar</Text>
            </Pressable>
            <Pressable
              style={[styles.actionBtn, styles.approveBtn]}
              onPress={() => { Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium); onApprove(alert.id); }}
            >
              <Feather name="check" size={14} color={Colors.accent} />
              <Text style={[styles.actionBtnText, { color: Colors.accent }]}>Aprovar</Text>
            </Pressable>
          </View>
        </View>
      )}
    </View>
  );
}
 
export default function DashboardScreen() {
  const insets = useSafeAreaInsets();
  const {
    threatLevel, processes, alerts, isMonitoring, shizukuConnected,
    startMonitoring, stopMonitoring, connectShizuku, resolveAlert, approveAction, denyAction,
  } = useSecurity();
 
  const activeAlerts = alerts.filter(a => !a.resolved).slice(0, 5);
  const suspiciousProcs = processes.filter(p => !p.trusted);
  const networkProcs = processes.filter(p => p.network);
 
  const handleMonitorToggle = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
    isMonitoring ? stopMonitoring() : startMonitoring();
  };
 
  const handleShizuku = async () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    await connectShizuku();
  };
 
  return (
    <ScrollView
      style={[styles.container, { paddingTop: insets.top + (Platform.OS === "web" ? 67 : 0) }]}
      contentContainerStyle={[styles.content, { paddingBottom: insets.bottom + 100 }]}
      showsVerticalScrollIndicator={false}
    >
      <View style={styles.header}>
        <View>
          <Text style={styles.appName}>CyberAgent</Text>
          <Text style={styles.appSub}>Android 16 · Segurança IA</Text>
        </View>
        <View style={[styles.shizukuBadge, { backgroundColor: shizukuConnected ? Colors.accent + "22" : Colors.surface }]}>
          <MaterialCommunityIcons
            name="key-variant"
            size={14}
            color={shizukuConnected ? Colors.accent : Colors.textSecondary}
          />
          <Text style={[styles.shizukuText, { color: shizukuConnected ? Colors.accent : Colors.textSecondary }]}>
            {shizukuConnected ? "Shizuku" : "Sem Root"}
          </Text>
        </View>
      </View>
 
      <ThreatRing level={threatLevel} />
 
      <Pressable
        style={[styles.monitorBtn, { backgroundColor: isMonitoring ? Colors.danger + "22" : Colors.primary + "22", borderColor: isMonitoring ? Colors.danger : Colors.primary }]}
        onPress={handleMonitorToggle}
      >
        <MaterialCommunityIcons
          name={isMonitoring ? "stop-circle" : "play-circle"}
          size={20}
          color={isMonitoring ? Colors.danger : Colors.primary}
        />
        <Text style={[styles.monitorBtnText, { color: isMonitoring ? Colors.danger : Colors.primary }]}>
          {isMonitoring ? "Parar Monitoramento" : "Iniciar Monitoramento"}
        </Text>
      </Pressable>
 
      {!shizukuConnected && (
        <Pressable style={styles.shizukuBtn} onPress={handleShizuku}>
          <MaterialCommunityIcons name="key" size={18} color={Colors.warning} />
          <Text style={styles.shizukuBtnText}>Conectar ao Shizuku</Text>
          <Feather name="chevron-right" size={16} color={Colors.warning} />
        </Pressable>
      )}
 
      <View style={styles.statsRow}>
        <StatCard icon="memory" label="Processos" value={`${processes.length}`} color={Colors.primary} />
        <StatCard icon="alert-circle" label="Suspeitos" value={`${suspiciousProcs.length}`} color={Colors.danger} />
        <StatCard icon="wifi" label="Rede" value={`${networkProcs.length}`} color={Colors.warning} />
      </View>
 
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Feather name="bell" size={15} color={Colors.primary} />
          <Text style={styles.sectionTitle}>Alertas Ativos</Text>
          {activeAlerts.length > 0 && (
            <View style={styles.badge}>
              <Text style={styles.badgeText}>{activeAlerts.length}</Text>
            </View>
          )}
        </View>
 
        {activeAlerts.length === 0 ? (
          <View style={styles.emptyState}>
            <MaterialCommunityIcons name="shield-check-outline" size={32} color={Colors.accent} />
            <Text style={styles.emptyText}>Nenhum alerta ativo</Text>
          </View>
        ) : (
          activeAlerts.map(alert => (
            <AlertItem
              key={alert.id}
              alert={alert}
              onResolve={resolveAlert}
              onApprove={approveAction}
              onDeny={denyAction}
            />
          ))
        )}
      </View>
 
      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <MaterialCommunityIcons name="information-outline" size={15} color={Colors.primary} />
          <Text style={styles.sectionTitle}>Status do Sistema</Text>
        </View>
        <View style={styles.systemInfo}>
          {[
            { label: "SO", value: "Android 16" },
            { label: "Firewall", value: "Ativo" },
            { label: "Anti-Phishing", value: "Ativo" },
            { label: "Modo Segundo Plano", value: "Ativo" },
          ].map(item => (
            <View key={item.label} style={styles.infoRow}>
              <Text style={styles.infoLabel}>{item.label}</Text>
              <View style={styles.infoValueWrap}>
                <View style={styles.activeDot} />
                <Text style={styles.infoValue}>{item.value}</Text>
              </View>
            </View>
          ))}
        </View>
      </View>
    </ScrollView>
  );
}
 
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  content: { paddingHorizontal: 20 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginBottom: 28, marginTop: 8 },
  appName: { fontFamily: "Inter_700Bold", fontSize: 24, color: Colors.textPrimary },
  appSub: { fontFamily: "Inter_400Regular", fontSize: 12, color: Colors.textSecondary, marginTop: 2 },
  shizukuBadge: { flexDirection: "row", alignItems: "center", gap: 5, paddingHorizontal: 10, paddingVertical: 5, borderRadius: 20, borderWidth: 1, borderColor: Colors.border },
  shizukuText: { fontFamily: "Inter_500Medium", fontSize: 11 },
  threatRingContainer: { alignItems: "center", justifyContent: "center", marginBottom: 28, height: 200 },
  outerRing: { position: "absolute", width: 190, height: 190, borderRadius: 95, borderWidth: 1 },
  middleRing: { position: "absolute", width: 160, height: 160, borderRadius: 80, borderWidth: 1 },
  innerCircle: { width: 130, height: 130, borderRadius: 65, borderWidth: 1.5, alignItems: "center", justifyContent: "center", gap: 4 },
  threatLabel: { fontFamily: "Inter_700Bold", fontSize: 11, letterSpacing: 2 },
  monitorBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, paddingVertical: 14, borderRadius: 14, borderWidth: 1, marginBottom: 12 },
  monitorBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 15 },
  shizukuBtn: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: Colors.warning + "18", borderWidth: 1, borderColor: Colors.warning + "44", borderRadius: 12, paddingHorizontal: 16, paddingVertical: 12, marginBottom: 20 },
  shizukuBtnText: { fontFamily: "Inter_500Medium", fontSize: 14, color: Colors.warning, flex: 1 },
  statsRow: { flexDirection: "row", gap: 10, marginBottom: 24 },
  statCard: { flex: 1, backgroundColor: Colors.surface, borderRadius: 14, padding: 14, alignItems: "center", gap: 6, borderWidth: 1, borderColor: Colors.border },
  statValue: { fontFamily: "Inter_700Bold", fontSize: 22, color: Colors.textPrimary },
  statLabel: { fontFamily: "Inter_400Regular", fontSize: 11, color: Colors.textSecondary, textAlign: "center" },
  section: { marginBottom: 24 },
  sectionHeader: { flexDirection: "row", alignItems: "center", gap: 7, marginBottom: 12 },
  sectionTitle: { fontFamily: "Inter_600SemiBold", fontSize: 15, color: Colors.textPrimary, flex: 1 },
  badge: { backgroundColor: Colors.danger, borderRadius: 10, minWidth: 20, height: 20, alignItems: "center", justifyContent: "center", paddingHorizontal: 6 },
  badgeText: { fontFamily: "Inter_700Bold", fontSize: 11, color: "#fff" },
  emptyState: { alignItems: "center", gap: 8, paddingVertical: 28, backgroundColor: Colors.surface, borderRadius: 14, borderWidth: 1, borderColor: Colors.border },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 14, color: Colors.textSecondary },
  alertItem: { backgroundColor: Colors.surface, borderRadius: 12, marginBottom: 8, borderLeftWidth: 3, overflow: "hidden", borderWidth: 1, borderColor: Colors.border },
  alertHeader: { flexDirection: "row", alignItems: "flex-start", padding: 12, gap: 10 },
  alertIconWrap: { width: 32, height: 32, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  alertContent: { flex: 1, gap: 2 },
  alertTitle: { fontFamily: "Inter_600SemiBold", fontSize: 13, color: Colors.textPrimary },
  alertDesc: { fontFamily: "Inter_400Regular", fontSize: 12, color: Colors.textSecondary, lineHeight: 16 },
  alertTime: { fontFamily: "Inter_400Regular", fontSize: 10, color: Colors.textSecondary + "88", marginTop: 2 },
  dismissBtn: { padding: 4 },
  actionRow: { borderTopWidth: 1, borderTopColor: Colors.border, paddingHorizontal: 12, paddingVertical: 10 },
  actionLabel: { fontFamily: "Inter_500Medium", fontSize: 12, color: Colors.textSecondary, marginBottom: 8 },
  actionBtns: { flexDirection: "row", gap: 8 },
  actionBtn: { flex: 1, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 6, paddingVertical: 8, borderRadius: 8, borderWidth: 1 },
  denyBtn: { backgroundColor: Colors.danger + "18", borderColor: Colors.danger + "44" },
  approveBtn: { backgroundColor: Colors.accent + "18", borderColor: Colors.accent + "44" },
  actionBtnText: { fontFamily: "Inter_600SemiBold", fontSize: 13 },
  systemInfo: { backgroundColor: Colors.surface, borderRadius: 14, borderWidth: 1, borderColor: Colors.border, overflow: "hidden" },
  infoRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: Colors.border },
  infoLabel: { fontFamily: "Inter_400Regular", fontSize: 13, color: Colors.textSecondary },
  infoValueWrap: { flexDirection: "row", alignItems: "center", gap: 6 },
  activeDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: Colors.accent },
  infoValue: { fontFamily: "Inter_500Medium", fontSize: 13, color: Colors.textPrimary },
});
