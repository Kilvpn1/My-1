import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useState } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Switch,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Colors from "@/constants/colors";
import { useSecurity, FirewallRule } from "@/context/SecurityContext";
 
function FirewallRuleCard({ rule, onToggle }: { rule: FirewallRule; onToggle: (pkg: string) => void }) {
  const isAllowed = rule.allowed;
 
  return (
    <View style={styles.ruleCard}>
      <View style={[styles.appIcon, { backgroundColor: isAllowed ? Colors.accent + "18" : Colors.danger + "18" }]}>
        <MaterialCommunityIcons
          name={isAllowed ? "wifi-check" : "wifi-off"}
          size={20}
          color={isAllowed ? Colors.accent : Colors.danger}
        />
      </View>
      <View style={styles.ruleInfo}>
        <Text style={styles.ruleName} numberOfLines={1}>{rule.appName}</Text>
        <Text style={styles.rulePkg} numberOfLines={1}>{rule.packageName}</Text>
        <Text style={styles.ruleTime}>
          Adicionado em {new Date(rule.createdAt).toLocaleDateString("pt-BR")}
        </Text>
      </View>
      <Switch
        value={isAllowed}
        onValueChange={() => {
          Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
          onToggle(rule.packageName);
        }}
        trackColor={{ false: Colors.danger + "66", true: Colors.accent + "66" }}
        thumbColor={isAllowed ? Colors.accent : Colors.danger}
      />
    </View>
  );
}
 
function StatsBar({ rules }: { rules: FirewallRule[] }) {
  const allowed = rules.filter(r => r.allowed).length;
  const blocked = rules.filter(r => !r.allowed).length;
 
  return (
    <View style={styles.statsBar}>
      <View style={styles.stat}>
        <MaterialCommunityIcons name="check-circle" size={20} color={Colors.accent} />
        <Text style={styles.statNum}>{allowed}</Text>
        <Text style={styles.statLabel}>Permitidos</Text>
      </View>
      <View style={styles.divider} />
      <View style={styles.stat}>
        <MaterialCommunityIcons name="block-helper" size={20} color={Colors.danger} />
        <Text style={styles.statNum}>{blocked}</Text>
        <Text style={styles.statLabel}>Bloqueados</Text>
      </View>
      <View style={styles.divider} />
      <View style={styles.stat}>
        <MaterialCommunityIcons name="shield-half-full" size={20} color={Colors.primary} />
        <Text style={styles.statNum}>{rules.length}</Text>
        <Text style={styles.statLabel}>Total</Text>
      </View>
    </View>
  );
}
 
type Filter = "all" | "allowed" | "blocked";
 
export default function FirewallScreen() {
  const insets = useSafeAreaInsets();
  const { firewallRules, toggleFirewall } = useSecurity();
  const [filter, setFilter] = useState<Filter>("all");
 
  const filtered = firewallRules.filter(r => {
    if (filter === "allowed") return r.allowed;
    if (filter === "blocked") return !r.allowed;
    return true;
  });
 
  const topPad = Platform.OS === "web" ? 67 : insets.top;
 
  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <Text style={styles.title}>Firewall</Text>
        <Text style={styles.sub}>Controle de acesso à rede por aplicativo</Text>
      </View>
 
      <StatsBar rules={firewallRules} />
 
      <View style={styles.infoBox}>
        <MaterialCommunityIcons name="information" size={16} color={Colors.primary} />
        <Text style={styles.infoText}>
          O firewall bloqueia o acesso à internet de aplicativos suspeitos. Todas as alterações requerem sua aprovação.
        </Text>
      </View>
 
      <View style={styles.filterRow}>
        {([["all", "Todos"], ["allowed", "Permitidos"], ["blocked", "Bloqueados"]] as [Filter, string][]).map(([key, label]) => (
          <Pressable
            key={key}
            style={[styles.filterBtn, filter === key && styles.filterBtnActive]}
            onPress={() => setFilter(key)}
          >
            <Text style={[styles.filterText, filter === key && styles.filterTextActive]}>
              {label}
            </Text>
          </Pressable>
        ))}
      </View>
 
      <FlatList
        data={filtered}
        renderItem={({ item }) => (
          <FirewallRuleCard rule={item} onToggle={toggleFirewall} />
        )}
        keyExtractor={item => item.id}
        contentContainerStyle={[styles.list, { paddingBottom: insets.bottom + 100 }]}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={styles.sep} />}
        ListEmptyComponent={
          <View style={styles.empty}>
            <MaterialCommunityIcons name="firewall" size={40} color={Colors.textSecondary} />
            <Text style={styles.emptyText}>Nenhuma regra de firewall</Text>
          </View>
        }
      />
    </View>
  );
}
 
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { paddingHorizontal: 20, paddingTop: 8, paddingBottom: 16 },
  title: { fontFamily: "Inter_700Bold", fontSize: 22, color: Colors.textPrimary },
  sub: { fontFamily: "Inter_400Regular", fontSize: 13, color: Colors.textSecondary, marginTop: 2 },
  statsBar: { flexDirection: "row", backgroundColor: Colors.surface, marginHorizontal: 16, borderRadius: 16, padding: 16, marginBottom: 12, borderWidth: 1, borderColor: Colors.border, alignItems: "center" },
  stat: { flex: 1, alignItems: "center", gap: 4 },
  statNum: { fontFamily: "Inter_700Bold", fontSize: 22, color: Colors.textPrimary },
  statLabel: { fontFamily: "Inter_400Regular", fontSize: 11, color: Colors.textSecondary },
  divider: { width: 1, height: 40, backgroundColor: Colors.border },
  infoBox: { flexDirection: "row", gap: 10, backgroundColor: Colors.primary + "14", borderWidth: 1, borderColor: Colors.primary + "33", borderRadius: 12, marginHorizontal: 16, padding: 12, marginBottom: 16, alignItems: "flex-start" },
  infoText: { fontFamily: "Inter_400Regular", fontSize: 12, color: Colors.textSecondary, flex: 1, lineHeight: 18 },
  filterRow: { flexDirection: "row", gap: 8, paddingHorizontal: 16, marginBottom: 16 },
  filterBtn: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border },
  filterBtnActive: { backgroundColor: Colors.primary + "22", borderColor: Colors.primary },
  filterText: { fontFamily: "Inter_500Medium", fontSize: 13, color: Colors.textSecondary },
  filterTextActive: { color: Colors.primary },
  list: { paddingHorizontal: 16 },
  ruleCard: { flexDirection: "row", alignItems: "center", gap: 12, backgroundColor: Colors.surface, borderRadius: 14, padding: 14, borderWidth: 1, borderColor: Colors.border },
  appIcon: { width: 44, height: 44, borderRadius: 12, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: Colors.border },
  ruleInfo: { flex: 1 },
  ruleName: { fontFamily: "Inter_600SemiBold", fontSize: 14, color: Colors.textPrimary },
  rulePkg: { fontFamily: "Inter_400Regular", fontSize: 11, color: Colors.textSecondary, marginTop: 2 },
  ruleTime: { fontFamily: "Inter_400Regular", fontSize: 10, color: Colors.textSecondary + "88", marginTop: 3 },
  sep: { height: 8 },
  empty: { alignItems: "center", gap: 10, paddingTop: 60 },
  emptyText: { fontFamily: "Inter_400Regular", fontSize: 14, color: Colors.textSecondary },
});
