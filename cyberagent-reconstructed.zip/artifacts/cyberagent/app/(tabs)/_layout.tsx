import { BlurView } from "expo-blur";
import { isLiquidGlassAvailable } from "expo-glass-effect";
import { Tabs } from "expo-router";
import { Icon, Label, NativeTabs } from "expo-router/unstable-native-tabs";
import { SymbolView } from "expo-symbols";
import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import React from "react";
import { Platform, StyleSheet, View, useColorScheme } from "react-native";
import Colors from "@/constants/colors";
import { useSecurity } from "@/context/SecurityContext";
 
function AlertBadge() {
  return null;
}
 
function NativeTabLayout() {
  return (
    <NativeTabs>
      <NativeTabs.Trigger name="index">
        <Icon sf={{ default: "shield", selected: "shield.fill" }} />
        <Label>Painel</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="chat">
        <Icon sf={{ default: "bubble.left", selected: "bubble.left.fill" }} />
        <Label>Chat IA</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="processes">
        <Icon sf={{ default: "cpu", selected: "cpu.fill" }} />
        <Label>Processos</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="firewall">
        <Icon sf={{ default: "lock.shield", selected: "lock.shield.fill" }} />
        <Label>Firewall</Label>
      </NativeTabs.Trigger>
      <NativeTabs.Trigger name="scanner">
        <Icon sf={{ default: "link.circle", selected: "link.circle.fill" }} />
        <Label>Scanner</Label>
      </NativeTabs.Trigger>
    </NativeTabs>
  );
}
 
function ClassicTabLayout() {
  const isIOS = Platform.OS === "ios";
  const isWeb = Platform.OS === "web";
 
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: Colors.primary,
        tabBarInactiveTintColor: Colors.textSecondary,
        headerShown: false,
        tabBarStyle: {
          position: "absolute",
          backgroundColor: isIOS ? "transparent" : Colors.surface,
          borderTopWidth: 1,
          borderTopColor: Colors.border,
          elevation: 0,
          ...(isWeb ? { height: 84 } : {}),
        },
        tabBarBackground: () =>
          isIOS ? (
            <BlurView
              intensity={80}
              tint="dark"
              style={StyleSheet.absoluteFill}
            />
          ) : (
            <View
              style={[StyleSheet.absoluteFill, { backgroundColor: Colors.surface }]}
            />
          ),
        tabBarLabelStyle: {
          fontFamily: "Inter_500Medium",
          fontSize: 10,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "Painel",
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="shield.fill" tintColor={color} size={22} />
            ) : (
              <MaterialCommunityIcons name="shield-check" size={22} color={color} />
            ),
        }}
      />
      <Tabs.Screen
        name="chat"
        options={{
          title: "Chat IA",
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="bubble.left.fill" tintColor={color} size={22} />
            ) : (
              <Feather name="message-circle" size={22} color={color} />
            ),
        }}
      />
      <Tabs.Screen
        name="processes"
        options={{
          title: "Processos",
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="cpu" tintColor={color} size={22} />
            ) : (
              <MaterialCommunityIcons name="monitor-dashboard" size={22} color={color} />
            ),
        }}
      />
      <Tabs.Screen
        name="firewall"
        options={{
          title: "Firewall",
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="lock.shield.fill" tintColor={color} size={22} />
            ) : (
              <MaterialCommunityIcons name="shield-lock" size={22} color={color} />
            ),
        }}
      />
      <Tabs.Screen
        name="scanner"
        options={{
          title: "Scanner",
          tabBarIcon: ({ color }) =>
            isIOS ? (
              <SymbolView name="link.circle.fill" tintColor={color} size={22} />
            ) : (
              <MaterialCommunityIcons name="link-variant-plus" size={22} color={color} />
            ),
        }}
      />
    </Tabs>
  );
}
 
export default function TabLayout() {
  if (isLiquidGlassAvailable()) {
    return <NativeTabLayout />;
  }
  return <ClassicTabLayout />;
}
