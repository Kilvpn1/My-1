import { Feather, MaterialCommunityIcons } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import React, { useRef, useState } from "react";
import {
  FlatList,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import Animated, { FadeIn } from "react-native-reanimated";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Colors from "@/constants/colors";
import { useChat, Message } from "@/context/ChatContext";
 
function TypingIndicator() {
  return (
    <View style={styles.typingWrap}>
      <View style={styles.typingBubble}>
        <View style={styles.typingDots}>
          {[0, 1, 2].map(i => (
            <View key={i} style={[styles.typingDot, { opacity: 0.4 + i * 0.3 }]} />
          ))}
        </View>
      </View>
    </View>
  );
}
 
function MessageBubble({ message }: { message: Message }) {
  const isUser = message.role === "user";
  const isSystem = message.role === "system";
 
  if (isSystem) return null;
 
  return (
    <Animated.View entering={FadeIn.duration(200)} style={[styles.msgRow, isUser && styles.msgRowUser]}>
      {!isUser && (
        <View style={styles.avatarWrap}>
          <MaterialCommunityIcons name="shield-check" size={16} color={Colors.primary} />
        </View>
      )}
      <View style={[styles.bubble, isUser ? styles.userBubble : styles.aiBubble]}>
        <Text style={[styles.bubbleText, isUser && styles.userBubbleText]}>
          {message.content}
        </Text>
        <Text style={[styles.timeText, isUser && { color: "rgba(255,255,255,0.5)" }]}>
          {new Date(message.timestamp).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}
        </Text>
      </View>
    </Animated.View>
  );
}
 
const QUICK_COMMANDS = [
  "Verificar processos suspeitos",
  "Status do firewall",
  "Escanear link",
  "Como proteger meu Android?",
];
 
export default function ChatScreen() {
  const insets = useSafeAreaInsets();
  const { messages, isStreaming, showTyping, sendMessage, clearChat } = useChat();
  const [input, setInput] = useState("");
  const inputRef = useRef<TextInput>(null);
  const flatListRef = useRef<FlatList>(null);
 
  const reversed = [...messages].reverse();
 
  const handleSend = async () => {
    const text = input.trim();
    if (!text || isStreaming) return;
    setInput("");
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    await sendMessage(text);
  };
 
  const handleQuick = (cmd: string) => {
    setInput(cmd);
    inputRef.current?.focus();
  };
 
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
 
  return (
    <View style={[styles.container, { paddingTop: topPad }]}>
      <View style={styles.header}>
        <View style={styles.headerLeft}>
          <MaterialCommunityIcons name="shield-check" size={22} color={Colors.primary} />
          <View>
            <Text style={styles.headerTitle}>CyberAgent IA</Text>
            <Text style={styles.headerSub}>{isStreaming ? "Respondendo..." : "Online"}</Text>
          </View>
        </View>
        <Pressable onPress={clearChat} style={styles.clearBtn}>
          <Feather name="trash-2" size={18} color={Colors.textSecondary} />
        </Pressable>
      </View>
 
      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={0}
      >
        <FlatList
          ref={flatListRef}
          data={reversed}
          renderItem={({ item }) => <MessageBubble message={item} />}
          keyExtractor={item => item.id}
          inverted={messages.length > 0}
          contentContainerStyle={styles.listContent}
          ListHeaderComponent={showTyping ? <TypingIndicator /> : null}
          keyboardDismissMode="interactive"
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        />
 
        {messages.length <= 1 && (
          <View style={styles.quickCmds}>
            <Text style={styles.quickLabel}>Comandos rápidos</Text>
            <View style={styles.quickGrid}>
              {QUICK_COMMANDS.map(cmd => (
                <Pressable
                  key={cmd}
                  style={({ pressed }) => [styles.quickChip, pressed && { opacity: 0.7 }]}
                  onPress={() => handleQuick(cmd)}
                >
                  <Text style={styles.quickChipText}>{cmd}</Text>
                </Pressable>
              ))}
            </View>
          </View>
        )}
 
        <View style={[styles.inputRow, { paddingBottom: bottomPad + 90 }]}>
          <View style={styles.inputWrap}>
            <TextInput
              ref={inputRef}
              style={styles.input}
              value={input}
              onChangeText={setInput}
              placeholder="Pergunte sobre segurança..."
              placeholderTextColor={Colors.textSecondary}
              multiline
              maxLength={1000}
              blurOnSubmit={false}
              onSubmitEditing={handleSend}
            />
          </View>
          <Pressable
            style={[styles.sendBtn, (!input.trim() || isStreaming) && styles.sendBtnDisabled]}
            onPress={handleSend}
            disabled={!input.trim() || isStreaming}
          >
            <Feather name="send" size={18} color={!input.trim() || isStreaming ? Colors.textSecondary : "#000"} />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}
 
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: Colors.bg },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: Colors.border },
  headerLeft: { flexDirection: "row", alignItems: "center", gap: 10 },
  headerTitle: { fontFamily: "Inter_600SemiBold", fontSize: 16, color: Colors.textPrimary },
  headerSub: { fontFamily: "Inter_400Regular", fontSize: 11, color: Colors.textSecondary },
  clearBtn: { padding: 6 },
  listContent: { paddingHorizontal: 16, paddingTop: 12, paddingBottom: 8 },
  msgRow: { flexDirection: "row", alignItems: "flex-end", marginBottom: 12, gap: 8 },
  msgRowUser: { flexDirection: "row-reverse" },
  avatarWrap: { width: 32, height: 32, borderRadius: 16, backgroundColor: Colors.primary + "22", alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: Colors.primary + "44" },
  bubble: { maxWidth: "78%", borderRadius: 18, padding: 12, paddingBottom: 8 },
  userBubble: { backgroundColor: Colors.primary, borderBottomRightRadius: 4 },
  aiBubble: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderBottomLeftRadius: 4 },
  bubbleText: { fontFamily: "Inter_400Regular", fontSize: 14, color: Colors.textPrimary, lineHeight: 20 },
  userBubbleText: { color: "#000" },
  timeText: { fontFamily: "Inter_400Regular", fontSize: 10, color: Colors.textSecondary, marginTop: 4, alignSelf: "flex-end" },
  typingWrap: { flexDirection: "row", alignItems: "flex-end", marginBottom: 12, gap: 8 },
  typingBubble: { backgroundColor: Colors.surface, borderRadius: 18, borderBottomLeftRadius: 4, padding: 14, borderWidth: 1, borderColor: Colors.border },
  typingDots: { flexDirection: "row", gap: 5 },
  typingDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: Colors.primary },
  quickCmds: { paddingHorizontal: 16, paddingBottom: 8 },
  quickLabel: { fontFamily: "Inter_500Medium", fontSize: 12, color: Colors.textSecondary, marginBottom: 8 },
  quickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 8 },
  quickChip: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 8 },
  quickChipText: { fontFamily: "Inter_400Regular", fontSize: 13, color: Colors.primary },
  inputRow: { flexDirection: "row", alignItems: "flex-end", paddingHorizontal: 16, paddingTop: 10, gap: 10, borderTopWidth: 1, borderTopColor: Colors.border, backgroundColor: Colors.bg },
  inputWrap: { flex: 1, backgroundColor: Colors.surface, borderRadius: 20, borderWidth: 1, borderColor: Colors.border, paddingHorizontal: 16, paddingVertical: 10, minHeight: 44 },
  input: { fontFamily: "Inter_400Regular", fontSize: 14, color: Colors.textPrimary, maxHeight: 100 },
  sendBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: Colors.primary, alignItems: "center", justifyContent: "center" },
  sendBtnDisabled: { backgroundColor: Colors.surface, borderWidth: 1, borderColor: Colors.border },
});
