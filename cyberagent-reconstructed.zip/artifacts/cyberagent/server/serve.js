const http = require("node:http");
const fs = require("node:fs");
const path = require("node:path");

const root = path.resolve(__dirname, "../dist");
const port = Number(process.env.PORT || 3000);

const server = http.createServer((req, res) => {
  const requestPath = (req.url || "/").split("?")[0];
  let filePath = path.join(root, requestPath === "/" ? "/index.html" : requestPath);
  if (!fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    filePath = path.join(root, "index.html");
  }
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.statusCode = 404;
      res.end("Not found");
      return;
    }
    res.end(data);
  });
});

server.listen(port, () => {
  console.log(`Serving Expo export on http://localhost:${port}`);
});
