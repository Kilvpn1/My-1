let baseUrl = "";
export function setBaseUrl(url: string) {
  baseUrl = url;
}
export function getBaseUrl() {
  return baseUrl;
}
